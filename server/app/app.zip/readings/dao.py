from sqlalchemy import select
from sqlalchemy.exc import SQLAlchemyError
from app.database import async_session_maker
from app.readings.models import Reading
from app.meters.models import Meter
from app.tariffs.dao import TariffDAO
from app.dao.base import BaseDAO
from decimal import Decimal


class ReadingsDAO(BaseDAO):
    model = Reading

    @classmethod
    async def find_meter_by_id(cls, meter_id: int):
        async with async_session_maker() as session:
            # Находим счетчик по id
            query = select(Meter).where(Meter.id == meter_id)
            result = await session.execute(query)
            return result.scalar_one_or_none()

    @classmethod
    async def add_new_reading(cls, meter_id: int, current_value: float):
        async with async_session_maker() as session:
            # Находим счетчик по id
            query = select(Meter).where(Meter.id == meter_id)
            result = await session.execute(query)
            meter = result.scalar_one_or_none()
            if not meter:
                raise ValueError("Счетчик не найден")

            # Получаем тариф для данного типа счетчика
            tariff = await TariffDAO.find_by_type(meter.type)
            if not tariff:
                raise ValueError(f"Тариф для типа счетчика '{meter.type}' не найден")

            # Получаем последнее показание для счетчика
            query = select(Reading).where(Reading.meter_id == meter_id).order_by(Reading.updated_at.desc())
            result = await session.execute(query)
            last_reading = result.scalars().first()

            # Рассчитываем предыдущее показание
            previous_value = last_reading.current_value if last_reading else None

            # Преобразуем current_value в Decimal
            current_value_decimal = Decimal(str(current_value))

            # Рассчитываем общую стоимость
            if previous_value is not None:
                total_cost = (current_value_decimal - previous_value) * tariff.rate
            else:
                total_cost = Decimal('0')

            # Создаем новое показание
            new_reading = Reading(
                meter_id=meter_id,
                current_value=current_value_decimal,
                previous_value=previous_value,
                tariff=tariff.rate,
                total_cost=total_cost,
            )

            # Добавляем новое показание в сессию
            session.add(new_reading)
            await session.commit()  # Фиксируем изменения
            await session.refresh(new_reading)  # Обновляем объект, чтобы получить его ID

            return new_reading

    @classmethod
    async def get_readings_by_property(cls, property_id: int):
        async with async_session_maker() as session:
            # Получаем все счетчики для объекта недвижимости
            query = select(Meter).where(Meter.property_id == property_id)
            result = await session.execute(query)
            meters = result.scalars().all()

            # Получаем показания для каждого счетчика
            readings = []
            for meter in meters:
                query = select(Reading).where(Reading.meter_id == meter.id)
                result = await session.execute(query)
                readings.extend(result.scalars().all())

            return readings
        
    @classmethod
    async def get_last_reading(cls, meter_id: int):
        """
        Получает последнее показание для счетчика.
        """
        async with async_session_maker() as session:
            query = select(Reading).where(Reading.meter_id == meter_id).order_by(Reading.updated_at.desc())
            result = await session.execute(query)
            last_reading = result.scalars().first()
            return last_reading
    
    @classmethod
    async def get_readings_by_date(cls, meter_id: int):
        """
        Получает все показания для счетчика, отсортированные по дате.
        """
        async with async_session_maker() as session:
            query = select(Reading).where(Reading.meter_id == meter_id).order_by(Reading.updated_at.desc())
            result = await session.execute(query)
            return result.scalars().all()
    
# class MetersDAO(BaseDAO):
#     model = Meter

#     @classmethod
#     async def create_meter(cls, property_id: int, type: str, meter_number: str):
#         async with async_session_maker() as session:
#             new_meter = Meter(
#                 property_id=property_id,
#                 type=type,
#                 meter_number=meter_number
#             )
#             session.add(new_meter)
#             await session.commit()
#             await session.refresh(new_meter)
#             return new_meter
    
#     @classmethod
#     async def get_meters_by_property(cls, property_id: int):
#         async with async_session_maker() as session:
#             query = select(Meter).where(Meter.property_id == property_id)
#             result = await session.execute(query)
#             return result.scalars().all()
    
#     @classmethod
#     async def get_meters_by_property(cls, property_id: int):
#         async with async_session_maker() as session:
#             query = select(Meter).where(Meter.property_id == property_id)
#             result = await session.execute(query)
#             return result.scalars().all()