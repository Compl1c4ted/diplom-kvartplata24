from sqlalchemy import Column, Integer, String, ForeignKey, Numeric, DateTime
from sqlalchemy.orm import relationship
from app.database import Base

# class Meter(Base):
#     __tablename__ = "meters"

#     id = Column(Integer, primary_key=True, autoincrement=True)
#     property_id = Column(Integer, ForeignKey("properties.id"), nullable=False)  # Связь с объектом недвижимости
#     type = Column(String, nullable=False)  # Тип счетчика: hot_water, cold_water, electricity_day, electricity_night
#     meter_number = Column(String, nullable=False, unique=True)  # Уникальный идентификатор счетчика

#     # Связь с объектом недвижимости
#     property = relationship("Property", back_populates="meters")
#     # Связь с показаниями
#     readings = relationship("Reading", back_populates="meter")


class Reading(Base):
    __tablename__ = "readings"

    id = Column(Integer, primary_key=True, autoincrement=True)
    meter_id = Column(Integer, ForeignKey("meters.id"), nullable=False)
    current_value = Column(Numeric, nullable=False)  # Текущее показание счетчика
    previous_value = Column(Numeric, nullable=True)  # Предыдущее показание счетчика
    tariff = Column(Numeric, nullable=False)  # Тариф (стоимость за единицу)
    total_cost = Column(Numeric, nullable=False)  # Общая стоимость (разница между текущим и предыдущим показанием * тариф)

    # Связь с счетчиком
    meter = relationship("Meter", back_populates="readings")