from sqlalchemy import select
from sqlalchemy.orm import joinedload
from app.database import async_session_maker
from app.dao.base import BaseDAO
from app.receipts.models import Receipt
from app.receipts.schemes import SReceiptCreate
from app.properties.models import Property
from fastapi import HTTPException
from app.receipts.pdf_generator import generate_receipt_pdf
import uuid


class ReceiptsDAO(BaseDAO):
    model = Receipt

    @classmethod
    async def get_receipt_with_property(cls, receipt_id: int):
        async with async_session_maker() as session:
            # Загружаем квитанцию вместе с связанным property
            query = select(cls.model).options(
                joinedload(Receipt.property)  # Жадно загружаем связанное property
            ).filter(Receipt.id == receipt_id)
            
            result = await session.execute(query)
            return result.scalars().first()
        
    @classmethod
    async def get_receipts_by_property(cls, property_id: int):
        async with async_session_maker() as session:
            query = select(cls.model).filter(Receipt.property_id == property_id)
            result = await session.execute(query)
            return result.scalars().all()
        
    @classmethod
    async def create_receipt(cls, receipt_data: SReceiptCreate):
        async with async_session_maker() as session:
            transaction_number = str(uuid.uuid4())[:8]
            receipt = Receipt(
                transaction_number=transaction_number,
                transaction_date=receipt_data.transaction_date,
                amount=receipt_data.amount,
                status="pending",
                property_id=receipt_data.property_id
            )
            session.add(receipt)
            await session.commit()
            await session.refresh(receipt)  # Важно для получения ID
            
            if receipt.id is None:  # Добавьте проверку
                raise Exception("Failed to get receipt ID after creation")
                
            return receipt

    @classmethod
    async def update_receipt_status(cls, receipt_id: int, status: str):
        async with async_session_maker() as session:
            # Получаем квитанцию
            query = select(cls.model).filter(Receipt.id == receipt_id)
            result = await session.execute(query)
            receipt = result.scalars().first()
            
            if receipt:
                receipt.status = status
                await session.commit()  # Используем await
                await session.refresh(receipt)  # Используем await
            return receipt
        
    @classmethod
    async def generate_pdf_for_receipt(cls, receipt_id: int):
        async with async_session_maker() as session:
            # Загружаем квитанцию вместе со связанными property и user
            query = select(cls.model).options(
                joinedload(Receipt.property).joinedload(Property.user)  # Добавляем загрузку user через property
            ).filter(Receipt.id == receipt_id)
            
            result = await session.execute(query)
            receipt = result.scalars().first()
            
            if not receipt:
                raise HTTPException(status_code=404, detail="Receipt not found")
            
            # Теперь user доступен через receipt.property.user
            pdf_buffer = await generate_receipt_pdf(receipt, receipt.property, receipt.property.user)
            return pdf_buffer
        
    @classmethod
    async def get_receipt_with_property_and_user(cls, receipt_id: int):
        async with async_session_maker() as session:
            query = select(cls.model).options(
                joinedload(Receipt.property).joinedload(Property.user)
            ).filter(Receipt.id == receipt_id)
            
            result = await session.execute(query)
            return result.scalars().first()