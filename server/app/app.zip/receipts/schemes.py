from pydantic import BaseModel, Field
from datetime import date as DateType
from enum import Enum

class ReceiptStatus(str, Enum):
    PENDING = "pending"
    PAID = "paid"
    FAILED = "failed"
    OVERDUE = "overdue"

class SReceiptBase(BaseModel):
    transaction_date: DateType = Field(..., description="Дата платежа")  # Используем DateType
    amount: float = Field(..., description="Сумма оплаты")
    property_id: int = Field(..., description="ID объекта недвижимости")

class SReceiptCreate(SReceiptBase):
    pass

class SReceiptResponse(SReceiptBase):
    id: int = Field(..., description="ID квитанции")
    transaction_number: str = Field(..., description="Уникальный номер транзакции")
    status: ReceiptStatus = Field(..., description="Статус квитанции (pending, paid, failed)")

    class Config:
        from_attributes = True
